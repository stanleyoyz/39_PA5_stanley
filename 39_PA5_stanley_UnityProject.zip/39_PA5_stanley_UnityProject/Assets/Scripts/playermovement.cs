﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class playermovement : MonoBehaviour
{
    public float speed;
    Rigidbody PlayerRigidbody;
    private float score = 0;
    public Text coincollect;
    // Start is called before the first frame update
    void Start()
    {
        PlayerRigidbody = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(moveHorizontal, 0, moveVertical);
        PlayerRigidbody.AddForce(movement * speed * Time.deltaTime);
        if(score >= 4)
        {
            SceneManager.LoadScene("gamewin");
        }
        
    }
    private void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.tag == "coin")
        {
            Destroy(other.gameObject);
            score += 1;
            coincollect.text = "Coins collected: " + score;
        }
        if (other.gameObject.tag == "obstacle")
        {
            SceneManager.LoadScene("gamelose");
        }
    }
   
}
